package com.example.tuan5

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item.view.*

class MoviesAdapter(var items: ArrayList<MoviesModel>, val context: Context) : RecyclerView.Adapter<MovieViewHolder>() {

    lateinit var mListener: MoviesCLickListener

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): MovieViewHolder {
        return MovieViewHolder(LayoutInflater.from(context).inflate(R.layout.item, parent, false))
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(movieViewHolder: MovieViewHolder, position: Int) {
        movieViewHolder.ititle.text = items[position].title
        movieViewHolder.ioverview.text = items[position].overview
        Glide.with(context)
            .load("https://image.tmdb.org/t/p/w500/" + items[position].poster_path)
            .into(movieViewHolder.iposter)


        movieViewHolder.itemView.setOnClickListener {
            mListener.onItemCLicked(position)
        }

        movieViewHolder.itemView.setOnLongClickListener {
            mListener.onItemLongCLicked(position)
            true
        }
    }

    fun setListener(listener: MoviesCLickListener) {
        this.mListener = listener
    }

    fun setData(items: ArrayList<MoviesModel>) {
        this.items = items
        notifyDataSetChanged()
    }
}




class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    var iposter = view.iposter
    var ititle = view.ititle
    var ioverview = view.ioverview

}
