package com.example.tuan5

interface MoviesCLickListener {
    fun onItemCLicked(position: Int)
    fun onItemLongCLicked(position: Int)
}