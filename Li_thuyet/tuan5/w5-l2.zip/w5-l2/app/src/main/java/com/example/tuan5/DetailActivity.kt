package com.example.tuan5

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail.*


class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        getAndPutData()
    }

    private fun getAndPutData() {
        val data = intent.extras
        if (data != null) {
            val title = data.getString(MOVIE_TITLE_KEY)
            val overview = data.getString(MOVIE_OVERVIEW_KEY)
            val backdrop = data.getString(MOVIE_BACKDROP_KEY)
            val date = data.getString(MOVIE_DATE_KEY)
            val video = data.getBoolean(MOVIE_VIDEO_KEY)
            val vote = data.getFloat(MOVIE_VOTE_KEY)


            ititle.text = title
            ioverview.text = overview
            idate.text = date
            rate.numStars= 8
            rate.rating = vote

            Glide.with(this)
                .load("https://image.tmdb.org/t/p/w500/" + backdrop)
                .into(ibackdrop)

            if (video)
                dplay.show()
            else dplay.hide()
        }
    }
}
