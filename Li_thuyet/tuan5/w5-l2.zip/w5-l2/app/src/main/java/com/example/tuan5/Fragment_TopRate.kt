package com.example.tuan5

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import java.util.*

class Fragment_TopRate: Fragment(), OnDataToFragmentListener {
    var movies: ArrayList<MoviesModel> = ArrayList()
    lateinit var movieAdapter: MoviesAdapter

    override fun sendDataToFragment(movies: ArrayList<MoviesModel>) {
        this.movies = movies
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_toprate, container,false)
        val recyclerView: RecyclerView = view.findViewById(R.id.rv_top_rate)

        recyclerView.layoutManager = LinearLayoutManager(activity)
        movieAdapter = MoviesAdapter(movies, activity as Context)
        recyclerView.adapter = movieAdapter
        movieAdapter.setListener(movieItemClickListener)

        return view
    }

    private val movieItemClickListener = object: MoviesCLickListener {
        override fun onItemCLicked(position: Int) {
            val intent = Intent(activity, DetailActivity:: class.java)
            intent.putExtra(MOVIE_TITLE_KEY, movies[position].title)
            intent.putExtra(MOVIE_OVERVIEW_KEY, movies[position].overview)
            intent.putExtra(MOVIE_BACKDROP_KEY, movies[position].backdrop_path)
            intent.putExtra(MOVIE_DATE_KEY, movies[position].release_date)
            intent.putExtra(MOVIE_VIDEO_KEY, movies[position].video)
            intent.putExtra(MOVIE_VOTE_KEY, movies[position].vote_average)
            startActivity(intent)
        }

        override fun onItemLongCLicked(position: Int) {
            // Dialog
        }
    }

    private fun randomInRange(min:Int, max:Int):Int{
        // Define a new Random class
        val r = Random()

        // Get the next random number within range
        // Including both minimum and maximum number
        return r.nextInt((max - min) + 1) + min;
    }
}