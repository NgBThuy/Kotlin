package com.example.tuan5

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity(){
    lateinit var mListener: OnDataToFragmentListener
    lateinit var mListenerTopRate: OnDataToFragmentListener

    var movies: ArrayList<MoviesModel> = ArrayList()
    var moviesTopRate: ArrayList<MoviesModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getDataMovie()
        getDataTopRate()

        addFirstFragment()

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.nav_view)
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
    }

    private fun addFirstFragment() {
        val nowPlayingFragment = Fragment_NowPlaying()
        mListener = nowPlayingFragment
        mListener.sendDataToFragment(movies)
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.frame_layout, nowPlayingFragment)
        fragmentTransaction.commit()
    }

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_toprate -> {
                val topRateFragment = Fragment_TopRate()
                mListenerTopRate = topRateFragment
                mListenerTopRate.sendDataToFragment(moviesTopRate)
                openFragment(topRateFragment)

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_nowplaying -> {
                val nowPlayingFragment = Fragment_NowPlaying()
                mListener = nowPlayingFragment
                mListener.sendDataToFragment(movies)
                openFragment(nowPlayingFragment)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    private fun openFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frame_layout, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun getDataMovie(){
        pbLoading.visibility = View.VISIBLE
        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/movie/now_playing?api_key=7519cb3f829ecd53bd9b7007076dbe23")
            .build()

        client.newCall(request)
            .enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        pbLoading.visibility = View.GONE
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val json = response.body()!!.string()
                    val jsonObject = JSONObject(json)
                    val jsonDataMovie = jsonObject.get("results").toString()

                    val collectionType = object : TypeToken<Collection<MoviesModel>>(){}.type

                    movies = Gson().fromJson(jsonDataMovie, collectionType)

                    runOnUiThread {
                        pbLoading.visibility = View.GONE
                    }
                }

            })
    }

    private fun getDataTopRate() {
        pbLoading.visibility = View.VISIBLE
        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://api.themoviedb.org/3/movie/top_rated?api_key=7519cb3f829ecd53bd9b7007076dbe23")
            .build()

        client.newCall(request)
            .enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        pbLoading.visibility = View.GONE
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val json = response.body()!!.string()
                    val jsonObject = JSONObject(json)
                    val jsonDataMovie = jsonObject.get("results").toString()

                    val collectionType = object : TypeToken<Collection<MoviesModel>>(){}.type

                    moviesTopRate = Gson().fromJson(jsonDataMovie, collectionType)

                    runOnUiThread {
                        pbLoading.visibility = View.GONE
                    }
                }
            })
    }
}

interface OnDataToFragmentListener {
    fun sendDataToFragment(movies: ArrayList<MoviesModel>)
}
